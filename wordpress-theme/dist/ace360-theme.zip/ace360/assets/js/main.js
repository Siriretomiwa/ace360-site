/**
 * Ace 360 page script: EN/NL switch, self-quote calculator, 3D hero tilt,
 * Lenis smooth scroll, reveals and navigation. All content works without it.
 */
(function () {
  'use strict';

  var root = document.documentElement;
  var body = document.body;
  var reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var finePointer = window.matchMedia('(pointer: fine)').matches;
  var gsap = window.gsap;
  var ScrollTrigger = window.ScrollTrigger;
  var hasGsap = !!(gsap && ScrollTrigger);
  var lenis = null;

  if (hasGsap) gsap.registerPlugin(ScrollTrigger);
  function lang() { return root.getAttribute('data-lang') === 'nl' ? 'nl' : 'en'; }

  /* ---------- Language ---------- */
  var langField = document.querySelector('[data-lang-field]');
  function applyLang(l, save) {
    root.setAttribute('data-lang', l);
    root.setAttribute('lang', l);
    document.querySelectorAll('[data-set-lang]').forEach(function (b) {
      b.setAttribute('aria-pressed', String(b.getAttribute('data-set-lang') === l));
    });
    if (langField) langField.value = l;
    if (save) { try { localStorage.setItem('ace360-lang', l); } catch (e) {} }
    document.dispatchEvent(new CustomEvent('ace360:lang', { detail: l }));
    if (hasGsap) ScrollTrigger.refresh();
  }
  document.querySelectorAll('[data-set-lang]').forEach(function (b) {
    b.addEventListener('click', function () { applyLang(b.getAttribute('data-set-lang'), true); });
  });
  applyLang(lang(), false);

  /* ---------- Day / night ---------- */
  // The new theme is revealed as a circle growing from the switch (or the lamp
  // that was clicked); film.js listens for 'ace360:theme' and relights the desk.
  var themeBtns = document.querySelectorAll('[data-theme-toggle]');
  function isNight() { return root.getAttribute('data-theme') === 'night'; }
  function syncThemeBtns() { themeBtns.forEach(function (b) { b.setAttribute('aria-pressed', String(isNight())); }); }
  function setTheme(night, from) {
    function apply() {
      root.setAttribute('data-theme', night ? 'night' : 'day');
      syncThemeBtns();
      try { localStorage.setItem('ace360-theme', night ? 'night' : 'day'); } catch (e) {}
      document.dispatchEvent(new CustomEvent('ace360:theme', { detail: { night: night } }));
    }
    if (document.startViewTransition && !reduced) {
      var x = from ? from.x : window.innerWidth - 60, y = from ? from.y : 30;
      var r = Math.hypot(Math.max(x, window.innerWidth - x), Math.max(y, window.innerHeight - y));
      var vt = document.startViewTransition(apply);
      vt.ready.then(function () {
        root.animate({ clipPath: ['circle(0px at ' + x + 'px ' + y + 'px)', 'circle(' + r + 'px at ' + x + 'px ' + y + 'px)'] },
          { duration: 750, easing: 'cubic-bezier(0.22, 1, 0.36, 1)', pseudoElement: '::view-transition-new(root)' });
      }).catch(function () {});
    } else {
      root.classList.add('theme-fade');
      apply();
      setTimeout(function () { root.classList.remove('theme-fade'); }, 650);
    }
  }
  themeBtns.forEach(function (b) {
    b.addEventListener('click', function () {
      var rc = b.getBoundingClientRect();
      setTheme(!isNight(), { x: rc.left + rc.width / 2, y: rc.top + rc.height / 2 });
    });
  });
  syncThemeBtns();
  window.ACE360_THEME = { set: setTheme, isNight: isNight };

  /* ---------- Smooth scroll ---------- */
  if (!reduced && typeof window.Lenis === 'function') {
    lenis = new window.Lenis({ lerp: 0.1, smoothWheel: true });
    if (hasGsap) {
      lenis.on('scroll', ScrollTrigger.update);
      gsap.ticker.add(function (time) { lenis.raf(time * 1000); });
      gsap.ticker.lagSmoothing(0);
    } else {
      var raf = function (t) { lenis.raf(t); requestAnimationFrame(raf); };
      requestAnimationFrame(raf);
    }
  }
  function headerH() { var h = document.querySelector('[data-header]'); return h ? h.offsetHeight : 0; }
  function scrollToEl(target) {
    var y = target.id === 'top' ? 0 : target.getBoundingClientRect().top + window.scrollY - headerH() + 1 - (parseFloat(getComputedStyle(target).scrollMarginTop) || 0);
    if (lenis) lenis.scrollTo(Math.max(0, y), { duration: 1.4 });
    else window.scrollTo({ top: Math.max(0, y), behavior: reduced ? 'auto' : 'smooth' });
  }
  document.addEventListener('click', function (e) {
    var link = e.target.closest('a[href*="#"]');
    if (!link) return;
    var url = new URL(link.href, window.location.href);
    if (url.pathname !== window.location.pathname || !url.hash || url.hash.length < 2) return;
    var target = document.getElementById(decodeURIComponent(url.hash.slice(1)));
    if (!target) return;
    e.preventDefault();
    closeNav();
    scrollToEl(target);
  });

  /* ---------- Header + progress ---------- */
  var header = document.querySelector('[data-header]');
  var bar = document.querySelector('.scroll-progress span');
  var lastY = window.scrollY;
  function onScroll() {
    var y = window.scrollY;
    var max = document.documentElement.scrollHeight - window.innerHeight;
    if (bar) bar.style.transform = 'scaleX(' + (max > 0 ? y / max : 0) + ')';
    if (header) {
      header.classList.toggle('is-scrolled', y > 8);
      header.classList.toggle('is-hidden', y > 600 && y > lastY + 2 && !body.classList.contains('nav-open'));
    }
    lastY = y;
  }
  if (lenis) lenis.on('scroll', onScroll); else window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  /* ---------- Mobile nav ---------- */
  var toggle = document.querySelector('.nav-toggle');
  function closeNav() {
    if (!body.classList.contains('nav-open')) return;
    body.classList.remove('nav-open');
    if (toggle) toggle.setAttribute('aria-expanded', 'false');
    if (lenis) lenis.start();
  }
  if (toggle) {
    toggle.addEventListener('click', function () {
      var open = !body.classList.contains('nav-open');
      body.classList.toggle('nav-open', open);
      toggle.setAttribute('aria-expanded', String(open));
      if (lenis) { if (open) lenis.stop(); else lenis.start(); }
    });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeNav(); });
  }

  /* ---------- Self-quote ---------- */
  var quote = document.querySelector('[data-quote]');
  var estField = document.querySelector('[data-estimate-field]');
  var estChip = document.querySelector('[data-estimate-chip]');
  var estChipText = document.querySelector('[data-estimate-chip-text]');
  var last = null;

  function money(n, l) {
    var s = new Intl.NumberFormat(l === 'nl' ? 'nl-NL' : 'en-GB', { maximumFractionDigits: 0 }).format(Math.round(n));
    return l === 'nl' ? '€ ' + s : '€' + s;
  }
  function round10(n) { return Math.round(n / 10) * 10; }
  function weeksText(a, b, l) {
    if (b <= 0) return l === 'nl' ? 'Direct' : 'Right away';
    var r = a === b ? String(a) : a + '–' + b;
    return r + (l === 'nl' ? (b === 1 ? ' week' : ' weken') : (b === 1 ? ' week' : ' weeks'));
  }

  if (quote) {
    var cfg = null;
    try { cfg = JSON.parse(quote.getAttribute('data-quote')); } catch (e) {}
    if (cfg && cfg.types) {
      var out = {
        range: quote.querySelector('[data-q-range]'),
        weeks: quote.querySelector('[data-q-weeks]'),
        care: quote.querySelector('[data-q-care]'),
        lines: quote.querySelector('[data-q-lines]'),
        pagesOut: quote.querySelector('[data-q-pages-out]')
      };
      var pagesStep = quote.querySelector('[data-q-pages]');
      var designStep = quote.querySelector('[data-q-design]');
      var range = quote.querySelector('#q_pages');
      var shown = { lo: 0, hi: 0 };

      var find = function (list, id) { return list.filter(function (x) { return x.id === id; })[0]; };
      var calc = function () {
        var type = find(cfg.types, (quote.querySelector('input[name="q_type"]:checked') || {}).value) || cfg.types[0];
        var design = find(cfg.design, (quote.querySelector('input[name="q_design"]:checked') || {}).value) || cfg.design[0];
        var pages = type.pages ? parseInt(range.value, 10) : type.incl;
        var lines = [];
        var lo = type.base[0], hi = type.base[1];
        lines.push({ label: type['label_' + lang()] + (type.pages ? ' · ' + pages + (lang() === 'nl' ? ' pagina’s' : ' pages') : ''), lo: type.base[0], hi: type.base[1] });
        if (type.pages && pages > type.incl) {
          var extra = pages - type.incl;
          lo += extra * type.perPage[0]; hi += extra * type.perPage[1];
          lines.push({ label: (lang() === 'nl' ? 'Extra pagina’s × ' : 'Extra pages × ') + extra, lo: extra * type.perPage[0], hi: extra * type.perPage[1] });
        }
        var siteType = type.id !== 'care';
        if (siteType && design.pct) {
          var dlo = type.base[0] * design.pct / 100, dhi = type.base[1] * design.pct / 100;
          lo += dlo; hi += dhi;
          lines.push({ label: design['label_' + lang()], lo: dlo, hi: dhi });
        }
        var extrasOn = Array.prototype.map.call(quote.querySelectorAll('input[name="q_extra"]:checked'), function (i) { return i.value; });
        cfg.extras.forEach(function (x) {
          if (extrasOn.indexOf(x.id) === -1) return;
          if (x.only && x.only.indexOf(type.id) === -1) return;
          lo += x.price[0]; hi += x.price[1];
          lines.push({ label: x['label_' + lang()], lo: x.price[0], hi: x.price[1] });
        });
        var w0 = type.weeks[0], w1 = type.weeks[1];
        if (type.pages && pages > 12) { w0 += 1; w1 += 1; }
        if (extrasOn.indexOf('brand') !== -1 && siteType) { w0 += 1; w1 += 1; }
        if (extrasOn.indexOf('motion') !== -1 && siteType) { w1 += 1; }
        var rush = quote.querySelector('#q_rush').checked && siteType;
        if (rush) {
          var rlo = lo * (cfg.rush.factor - 1), rhi = hi * (cfg.rush.factor - 1);
          lo += rlo; hi += rhi;
          w0 = Math.max(1, w0 - cfg.rush.weeks); w1 = Math.max(1, w1 - cfg.rush.weeks);
          lines.push({ label: lang() === 'nl' ? 'Spoed' : 'Rush', lo: rlo, hi: rhi });
        }
        var care = quote.querySelector('#q_care').checked || type.id === 'care';
        var vat = quote.querySelector('#q_vat').checked ? 1 + cfg.vat / 100 : 1;
        return { type: type, pages: pages, lo: round10(lo * vat), hi: round10(hi * vat), w0: w0, w1: w1, care: care, vat: vat > 1, lines: lines, mult: vat };
      };

      var render = function (animate) {
        var r = calc();
        last = r;
        var l = lang();
        // dependent controls
        pagesStep.disabled = !r.type.pages;
        designStep.disabled = r.type.id === 'care';
        quote.querySelectorAll('[data-only]').forEach(function (el) {
          var ok = el.getAttribute('data-only').split(' ').indexOf(r.type.id) !== -1;
          el.hidden = !ok;
        });
        if (out.pagesOut) out.pagesOut.textContent = r.type.pages ? r.pages : r.type.incl || '—';
        range.style.setProperty('--p', ((range.value - range.min) / (range.max - range.min) * 100) + '%');
        // numbers
        var set = function () {
          out.range.textContent = money(shown.lo, l) + ' – ' + money(shown.hi, l);
        };
        if (animate && hasGsap && !reduced) {
          gsap.to(shown, { lo: r.lo, hi: r.hi, duration: 0.6, ease: 'power3.out', onUpdate: set, overwrite: true });
        } else {
          shown.lo = r.lo; shown.hi = r.hi; set();
        }
        out.weeks.textContent = weeksText(r.w0, r.w1, l);
        out.care.textContent = r.care ? money(cfg.care * (r.vat ? 1 + cfg.vat / 100 : 1), l) + (l === 'nl' ? ' /mnd' : ' /mo') : (l === 'nl' ? 'Geen' : 'None');
        out.lines.innerHTML = '';
        r.lines.forEach(function (line) {
          var li = document.createElement('li');
          var a = document.createElement('span'); a.textContent = line.label;
          var b = document.createElement('span'); b.textContent = '+' + money(round10(line.lo * r.mult), l);
          li.appendChild(a); li.appendChild(b);
          out.lines.appendChild(li);
        });
        if (estChip && !estChip.hidden) chip();
        document.dispatchEvent(new CustomEvent('ace360:quote', { detail: {
          lang: l,
          lines: r.lines.map(function (x) { return [x.label, '+' + money(round10(x.lo * r.mult), l)]; }),
          range: money(r.lo, l) + ' – ' + money(r.hi, l),
          weeks: weeksText(r.w0, r.w1, l),
          care: r.care ? money(cfg.care * (r.vat ? 1 + cfg.vat / 100 : 1), l) + (l === 'nl' ? ' /mnd' : ' /mo') : (l === 'nl' ? 'geen' : 'none'),
          vat: r.vat ? (l === 'nl' ? 'incl. btw' : 'incl. VAT') : (l === 'nl' ? 'excl. btw' : 'excl. VAT')
        } }));
      };

      var summary = function (r, l) {
        var parts = r.lines.map(function (x) { return x.label; });
        return parts.join(', ') + ' — ' + money(r.lo, l) + '–' + money(r.hi, l) + (r.vat ? (l === 'nl' ? ' incl. btw' : ' incl. VAT') : (l === 'nl' ? ' excl. btw' : ' excl. VAT')) + ', ' + weeksText(r.w0, r.w1, l) + (r.care ? (l === 'nl' ? ', met onderhoud' : ', with care plan') : '');
      };
      var chip = function () { if (estChipText && last) estChipText.textContent = summary(last, lang()); };

      quote.addEventListener('input', function () { render(true); });
      quote.addEventListener('change', function () { render(true); });
      document.addEventListener('ace360:lang', function () { render(false); });
      render(false);

      // service cards preselect a project type
      document.querySelectorAll('[data-pick-type]').forEach(function (a) {
        a.addEventListener('click', function () {
          var input = quote.querySelector('#q_type_' + a.getAttribute('data-pick-type'));
          if (input) { input.checked = true; render(true); }
        });
      });

      var send = quote.querySelector('[data-q-send]');
      if (send) {
        send.addEventListener('click', function () {
          var r = last;
          if (estField) {
            // the email always gets the English line, whatever the visitor's language
            var saved = root.getAttribute('data-lang');
            root.setAttribute('data-lang', 'en');
            estField.value = summary(calc(), 'en');
            root.setAttribute('data-lang', saved);
          }
          if (estChip) { estChip.hidden = false; chip(); }
          var needVal = r.type.id === 'store' ? 'Online store' : r.type.id === 'care' ? 'Maintenance' : 'Website';
          var need = document.querySelector('input[name="ace360_need"][value="' + needVal + '"]');
          if (need) need.checked = true;
          showTab('write');
          var contact = document.getElementById('write');
          if (contact) scrollToEl(contact);
          setTimeout(function () { var n = document.getElementById('ace360_name'); if (n) n.focus({ preventScroll: true }); }, 1400);
        });
      }
    }
  }

  /* ---------- "Build a homepage": chips rebuild the site on the laptop ---------- */
  var tryBox = document.querySelector('[data-try]');
  if (tryBox) {
    var tryVal = function (n) { var i = tryBox.querySelector('input[name="' + n + '"]:checked'); return i ? i.value : ''; };
    var tryQuote = function () { var i = tryBox.querySelector('input[name="try_sector"]:checked'); try { return JSON.parse(i.getAttribute('data-quote')); } catch (e) { return null; } };
    var liveOn = function (w1) { var d = new Date(); d.setDate(d.getDate() + 7); while (d.getDay() !== 1) d.setDate(d.getDate() + 1); d.setDate(d.getDate() + (w1 - 1) * 7 + 4); return d; };
    var tryOut = function () {
      var q = tryQuote(), l = lang(); if (!q) return;
      tryBox.querySelector('[data-try-price]').textContent = money(q.lo, l) + ' – ' + money(q.hi, l);
      tryBox.querySelector('[data-try-date]').textContent = (l === 'nl' ? 'live op ' : 'live by ') + new Intl.DateTimeFormat(l === 'nl' ? 'nl-NL' : 'en-GB', { weekday: 'long', day: 'numeric', month: 'long' }).format(liveOn(q.w1)) + ' · ' + q.w0 + '–' + q.w1 + (l === 'nl' ? ' weken' : ' weeks');
    };
    var tryBuild = function () { document.dispatchEvent(new CustomEvent('ace360:try', { detail: { key: tryVal('try_sector'), mood: tryVal('try_mood') } })); tryOut(); };
    tryBox.addEventListener('change', tryBuild);
    tryBox.querySelector('[data-try-build]').addEventListener('click', tryBuild);
    document.addEventListener('ace360:lang', tryOut);
    tryOut();
    var use = tryBox.querySelector('[data-try-use]');
    if (use && quote) use.addEventListener('click', function () {
      var q = tryQuote(); if (!q) return;
      var t = quote.querySelector('#q_type_' + q.type); if (t) t.checked = true;
      quote.querySelectorAll('input[name="q_extra"]').forEach(function (x) { x.checked = q.extras.indexOf(x.value) !== -1; });
      quote.dispatchEvent(new Event('change', { bubbles: true }));
    });
  }

  /* ---------- Contact form in the static preview ---------- */
  var form = document.querySelector('[data-contact-form]');
  if (form && window.ACE360_PREVIEW) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var note = form.querySelector('[data-form-preview]');
      if (note) {
        note.textContent = lang() === 'nl'
          ? 'Alleen voorbeeld: in WordPress mailt dit formulier de aanvraag naar ' + 'hello@ace360services.nl.'
          : 'Preview only: in WordPress this form emails the enquiry to hello@ace360services.nl.';
        note.hidden = false;
        note.scrollIntoView({ block: 'nearest' });
      }
    });
  }

  /* ---------- Contact tabs: book a call / send a message ---------- */
  var tabsSec = document.querySelector('[data-tabs]');
  var showTab = function () {};
  if (tabsSec) {
    var tabBtns = tabsSec.querySelectorAll('[data-tab]');
    showTab = function (name, focus) {
      tabBtns.forEach(function (b) {
        var on = b.getAttribute('data-tab') === name;
        b.setAttribute('aria-selected', String(on));
        b.tabIndex = on ? 0 : -1;
        if (on && focus) b.focus();
      });
      tabsSec.querySelectorAll('[data-panel]').forEach(function (p) { p.hidden = p.getAttribute('data-panel') !== name; });
      if (hasGsap) ScrollTrigger.refresh();
    };
    tabBtns.forEach(function (b, i) {
      b.addEventListener('click', function () { showTab(b.getAttribute('data-tab')); });
      b.addEventListener('keydown', function (e) {
        if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') return;
        var n = tabBtns[(i + (e.key === 'ArrowRight' ? 1 : tabBtns.length - 1)) % tabBtns.length];
        showTab(n.getAttribute('data-tab'), true);
      });
    });
    showTab(window.location.hash === '#write' ? 'write' : tabsSec.getAttribute('data-tabs'));
    // links to #book or #write open that tab before the page scrolls to it
    document.addEventListener('click', function (e) {
      var a = e.target.closest('a[href$="#book"], a[href$="#write"]');
      if (a) showTab(a.getAttribute('href').split('#')[1]);
    }, true);
  }

  /* ---------- Book a call: free times in the visitor's own time zone ---------- */
  var book = document.querySelector('[data-book]');
  if (book) (function () {
    var rules = JSON.parse(book.getAttribute('data-rules') || '{}');
    var api = (book.getAttribute('data-api') || '').replace(/\/$/, '');
    var mail = book.getAttribute('data-mail') || '';
    var demo = !!window.ACE360_PREVIEW || !api;
    var DEMO_KEY = 'ace360-demo-calls';
    var vtz = rules.tz;
    try { vtz = Intl.DateTimeFormat().resolvedOptions().timeZone || rules.tz; } catch (e) {}
    function $(s) { return book.querySelector(s); }
    var daysEl = $('[data-book-days]'), timesEl = $('[data-book-times]'), msg = $('[data-book-msg]');
    var bform = $('[data-book-form]'), done = $('[data-book-done]'), err = $('[data-book-error]'), btn = $('[data-book-submit]');
    var slots = null, day = null, picked = null, booked = null;
    var T = {
      en: {
        tz: 'Times in your time zone', loading: 'Loading free times…',
        none: 'No free times in the coming weeks. Email {mail} and we find a moment.',
        fail: 'The calendar could not load. Email {mail} and we plan the call by email.',
        taken: 'Someone just took that time. Please pick another one.',
        busy: 'Too many attempts from this connection. Please email {mail}.',
        invalid: 'Please fill in your name, email and phone number, and tick the box.',
        error: 'Something went wrong. Please try again, or email {mail}.',
        title: 'Your call is booked',
        text: '{when}, {len} minutes. A confirmation with a calendar invite is on its way to {email}.',
        demo: 'Preview only: on the live site this books the call and emails you both.',
        sending: 'Booking…'
      },
      nl: {
        tz: 'Tijden in jouw tijdzone', loading: 'Vrije tijden laden…',
        none: 'Geen vrije tijden in de komende weken. Mail {mail} en we zoeken een moment.',
        fail: 'De agenda kon niet laden. Mail {mail} en we plannen het gesprek per mail.',
        taken: 'Iemand heeft die tijd net geboekt. Kies een andere.',
        busy: 'Te veel pogingen vanaf deze verbinding. Mail {mail}.',
        invalid: 'Vul je naam, e-mail en telefoonnummer in en vink het vakje aan.',
        error: 'Er ging iets mis. Probeer het opnieuw, of mail {mail}.',
        title: 'Je gesprek staat vast',
        text: '{when}, {len} minuten. Een bevestiging met agenda-uitnodiging is onderweg naar {email}.',
        demo: 'Alleen voorbeeld: op de echte site boekt dit het gesprek en krijgen jullie allebei een mail.',
        sending: 'Bezig…'
      }
    };
    function t(k, v) {
      v = v || {}; v.mail = v.mail || mail;
      return T[lang()][k].replace(/\{(\w+)\}/g, function (m, n) { return v[n] !== undefined ? v[n] : m; });
    }
    function say(s) { msg.textContent = s; msg.hidden = !s; }

    /* dates, always shown in the visitor's zone */
    function fmt(ts, o) {
      var opts = { timeZone: vtz }; for (var k in o) opts[k] = o[k];
      try { return new Intl.DateTimeFormat(lang() === 'nl' ? 'nl-NL' : 'en-GB', opts).format(new Date(ts * 1000)); }
      catch (e) { delete opts.timeZone; return new Intl.DateTimeFormat('en-GB', opts).format(new Date(ts * 1000)); }
    }
    function dayKey(ts) { return fmt(ts, { year: 'numeric', month: '2-digit', day: '2-digit' }); }
    function hm(ts) { return fmt(ts, { hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }); }
    function when(ts) { var s = fmt(ts, { weekday: 'long', day: 'numeric', month: 'long' }) + ' · ' + hm(ts); return s.charAt(0).toUpperCase() + s.slice(1); }

    /* the preview has no server: work the free times out from the same rules */
    function partsIn(ms, tz) {
      var p = {};
      new Intl.DateTimeFormat('en-US', { timeZone: tz, hourCycle: 'h23', year: 'numeric', month: 'numeric', day: 'numeric', hour: 'numeric', minute: 'numeric' })
        .formatToParts(new Date(ms)).forEach(function (x) { p[x.type] = +x.value; });
      return p;
    }
    function zoned(y, m, d, mins, tz) { // wall-clock time in tz → epoch ms
      var want = Date.UTC(y, m - 1, d, 0, mins), ms = want;
      for (var i = 0; i < 2; i++) { var p = partsIn(ms, tz); ms += want - Date.UTC(p.year, p.month - 1, p.day, p.hour % 24, p.minute); }
      return ms;
    }
    function demoTaken() { try { return JSON.parse(localStorage.getItem(DEMO_KEY)) || []; } catch (e) { return []; } }
    function localSlots() {
      var out = [], now = Date.now(), min = now + rules.notice * 3600e3, p = partsIn(now, rules.tz), mine = demoTaken();
      for (var i = 0; i < rules.days; i++) {
        var d = new Date(Date.UTC(p.year, p.month - 1, p.day + i));
        var Y = d.getUTCFullYear(), M = d.getUTCMonth() + 1, D = d.getUTCDate();
        if (rules.off.indexOf(Y + '-' + ('0' + M).slice(-2) + '-' + ('0' + D).slice(-2)) !== -1) continue;
        (rules.week[d.getUTCDay()] || []).forEach(function (w) {
          for (var m = w[0]; m + rules.len <= w[1]; m += rules.step) {
            var ts = Math.round(zoned(Y, M, D, m, rules.tz) / 1000);
            if (ts * 1000 >= min && mine.indexOf(ts) === -1) out.push(ts);
          }
        });
      }
      return out;
    }

    function load(then) {
      say(t('loading'));
      if (demo) { slots = localSlots(); render(); if (then) then(); return; }
      fetch(api + '/slots', { credentials: 'same-origin', cache: 'no-store' })
        .then(function (r) { if (!r.ok) throw new Error(r.status); return r.json(); })
        .then(function (d) { slots = d.slots || []; render(); if (then) then(); })
        .catch(function () { slots = null; daysEl.innerHTML = ''; timesEl.innerHTML = ''; say(t('fail')); });
    }

    function render() {
      $('[data-book-tz]').textContent = t('tz') + ': ' + vtz.replace(/_/g, ' ');
      if (booked) { doneText(); return; }
      if (!slots) return;
      var groups = {}, order = [];
      slots.forEach(function (s) { var k = dayKey(s); if (!groups[k]) { groups[k] = []; order.push(k); } groups[k].push(s); });
      var sl = daysEl.scrollLeft;
      daysEl.innerHTML = ''; timesEl.innerHTML = '';
      if (!order.length) { say(t('none')); bform.hidden = true; return; }
      say('');
      if (!groups[day]) day = order[0];
      order.forEach(function (k) {
        var s0 = groups[k][0], b = document.createElement('button');
        b.type = 'button'; b.className = 'book-day';
        b.setAttribute('aria-pressed', String(k === day));
        b.setAttribute('aria-label', fmt(s0, { weekday: 'long', day: 'numeric', month: 'long' }));
        b.innerHTML = '<span class="mono">' + fmt(s0, { weekday: 'short' }) + '</span><b>' + fmt(s0, { day: 'numeric' }) + '</b><span class="mono">' + fmt(s0, { month: 'short' }) + '</span>';
        b.addEventListener('click', function () { day = k; picked = null; render(); });
        daysEl.appendChild(b);
      });
      daysEl.scrollLeft = sl;
      groups[day].forEach(function (s) {
        var b = document.createElement('button');
        b.type = 'button'; b.className = 'book-time'; b.textContent = hm(s);
        b.setAttribute('aria-pressed', String(s === picked));
        b.addEventListener('click', function () { pick(s); });
        timesEl.appendChild(b);
      });
      bform.hidden = !picked;
      if (picked) $('[data-book-picked]').textContent = when(picked);
    }

    function pick(s) {
      picked = s; err.hidden = true; render();
      if (bform.getBoundingClientRect().top > window.innerHeight * 0.75) scrollToEl(bform);
      var n = $('#book_name'); if (n && !n.value) setTimeout(function () { n.focus({ preventScroll: true }); }, 50);
    }

    function syncVia() {
      var v = bform.querySelector('input[name="via"]:checked'), video = !!v && v.value === 'video';
      $('#book_phone').required = !video;
      $('[data-book-phone]').classList.toggle('is-optional', video);
    }
    bform.addEventListener('change', syncVia);
    syncVia();

    function fail(k) { err.textContent = t(k); err.hidden = false; }

    function icsFor(b) {
      var d = function (s) { return new Date(s * 1000).toISOString().replace(/[-:]/g, '').replace(/\.\d{3}/, ''); };
      var esc = function (s) { return String(s).replace(/([\;,])/g, '\\$1').replace(/\n/g, '\\n'); };
      return ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//Ace 360 Services//Call booking//EN', 'CALSCALE:GREGORIAN', 'BEGIN:VEVENT',
        'UID:' + b.uid, 'DTSTAMP:' + d(Date.now() / 1000), 'DTSTART:' + d(b.start), 'DTEND:' + d(b.start + rules.len * 60),
        'SUMMARY:' + esc('Ace 360 Services × ' + b.name), 'END:VEVENT', 'END:VCALENDAR'].join('\r\n') + '\r\n';
    }
    function doneText() {
      $('[data-book-done-title]').textContent = t('title');
      $('[data-book-done-text]').textContent = t('text', { when: when(booked.start), len: rules.len, email: booked.email }) + (booked.demo ? ' ' + t('demo') : '');
    }
    function finish(data, uid) {
      booked = { start: picked, name: data.name, email: data.email, uid: uid, demo: demo };
      bform.hidden = true; daysEl.hidden = true; timesEl.hidden = true; say('');
      done.hidden = false;
      doneText();
      var a = $('[data-book-ics]');
      // in the static preview the emailed invite stands in for the download
      if (demo) a.hidden = true;
      else try { a.href = URL.createObjectURL(new Blob([icsFor(booked)], { type: 'text/calendar' })); } catch (e) { a.hidden = true; }
      done.focus({ preventScroll: true });
      if (hasGsap) ScrollTrigger.refresh();
    }

    bform.addEventListener('submit', function (e) {
      e.preventDefault();
      if (!picked) return;
      var data = { start: picked, tz: vtz, lang: lang() };
      new FormData(bform).forEach(function (v, k) { data[k] = v; });
      var label = btn.innerHTML;
      btn.disabled = true; btn.textContent = t('sending'); err.hidden = true;
      var reset = function () { btn.disabled = false; btn.innerHTML = label; };
      if (demo) {
        setTimeout(function () {
          var mine = demoTaken(); mine.push(picked);
          try { localStorage.setItem(DEMO_KEY, JSON.stringify(mine)); } catch (x) {}
          reset(); finish(data, 'ace360-demo-' + picked + '@ace360services.nl');
        }, 600);
        return;
      }
      fetch(api + '/book', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) })
        .then(function (r) { return r.json().catch(function () { return {}; }).then(function (j) { return { s: r.status, j: j }; }); })
        .then(function (r) {
          reset();
          if (r.s === 200 && r.j.ok) { finish(data, r.j.uid); return; }
          if (r.s === 409) { picked = null; load(function () { say(t('taken')); }); return; }
          fail(r.s === 429 ? 'busy' : r.s === 400 ? 'invalid' : 'error');
        })
        .catch(function () { reset(); fail('error'); });
    });

    document.addEventListener('ace360:lang', render);
    load();
  })();

  /* ---------- Chapters tell the 3D laptop what to show ---------- */
  function film() { return window.ACE360_FILM; }
  function show(key, image, title) { var f = film(); if (f && key) f.setScreen(key, image, title); }
  if (hasGsap) {
    document.querySelectorAll('[data-k][data-screen]:not(.tall)').forEach(function (ch) {
      ScrollTrigger.create({
        trigger: ch, start: 'top 55%', end: 'bottom 45%',
        onToggle: function (self) { if (self.isActive) show(ch.getAttribute('data-screen')); }
      });
    });

    /* Work: the copy cycles through projects while the laptop shows each one */
    document.querySelectorAll('.ch.tall').forEach(function (ch) {
      var items = ch.querySelectorAll('.item');
      var dots = ch.querySelectorAll('[data-go]');
      var count = ch.querySelector('[data-count]');
      var n = items.length, idx = -1, st;
      function progress() {
        var top = ch.getBoundingClientRect().top + window.scrollY;
        return Math.min(1, Math.max(0, (window.scrollY - top) / Math.max(1, ch.offsetHeight - window.innerHeight)));
      }
      function activate(i, force) {
        if (i === idx && !force) return;
        idx = i;
        items.forEach(function (it, j) { it.classList.toggle('is-on', j === i); });
        dots.forEach(function (d, j) { d.classList.toggle('on', j === i); });
        if (count) count.textContent = (i + 1) + ' / ' + n;
        if (st && st.isActive) show(items[i].getAttribute('data-screen'), items[i].getAttribute('data-image'), items[i].getAttribute('data-title'));
      }
      st = ScrollTrigger.create({
        trigger: ch, start: 'top 55%', end: 'bottom 45%',
        onUpdate: function () { activate(Math.min(n - 1, Math.floor(progress() * n * 0.999))); },
        onToggle: function (self) { if (self.isActive) activate(Math.min(n - 1, Math.floor(progress() * n * 0.999)), true); }
      });
      dots.forEach(function (d) {
        d.addEventListener('click', function () {
          var i = parseInt(d.getAttribute('data-go'), 10);
          var top = ch.getBoundingClientRect().top + window.scrollY;
          var y = top + (ch.offsetHeight - window.innerHeight) * ((i + 0.5) / n);
          if (lenis) lenis.scrollTo(y, { duration: 1.2 }); else window.scrollTo({ top: y, behavior: 'smooth' });
        });
      });
    });
  }

  /* ---------- Selected work: a swipeable track with arrows, drag and a progress bar ---------- */
  document.querySelectorAll('[data-slider]').forEach(function (sl) {
    var track = sl.querySelector('[data-track]'), bar = sl.querySelector('[data-slider-bar]');
    var sec = sl.closest('section'), btns = sec ? sec.querySelectorAll('[data-slide]') : [];
    function stepW() { var s = track.children; return s.length > 1 ? s[1].offsetLeft - s[0].offsetLeft : track.clientWidth * 0.8; }
    function go(dir) { track.scrollBy({ left: stepW() * dir, behavior: reduced ? 'auto' : 'smooth' }); }
    function update() {
      var max = track.scrollWidth - track.clientWidth, p = max > 0 ? track.scrollLeft / max : 0;
      var f = Math.min(1, track.clientWidth / Math.max(1, track.scrollWidth));
      if (bar) { bar.style.width = (f * 100) + '%'; bar.style.transform = 'translateX(' + (p * (1 - f) / f * 100) + '%)'; }
      btns.forEach(function (b) { b.disabled = +b.getAttribute('data-slide') < 0 ? track.scrollLeft < 4 : track.scrollLeft > max - 4; });
    }
    btns.forEach(function (b) { b.addEventListener('click', function () { go(+b.getAttribute('data-slide')); }); });
    track.addEventListener('scroll', update, { passive: true });
    window.addEventListener('resize', update);
    update();
    track.addEventListener('keydown', function (e) {
      if (e.key === 'ArrowRight' || e.key === 'ArrowLeft') { e.preventDefault(); go(e.key === 'ArrowRight' ? 1 : -1); }
    });
    // drag with a mouse (touch already swipes natively)
    var down = null, moved = false;
    track.addEventListener('pointerdown', function (e) {
      if (e.pointerType !== 'mouse' || e.button !== 0) return;
      down = { x: e.clientX, left: track.scrollLeft }; moved = false;
    });
    window.addEventListener('pointermove', function (e) {
      if (!down) return;
      var dx = e.clientX - down.x;
      if (!moved && Math.abs(dx) > 6) { moved = true; track.classList.add('is-drag'); }
      if (moved) track.scrollLeft = down.left - dx;
    });
    window.addEventListener('pointerup', function () {
      if (!down) return;
      down = null;
      if (moved) { track.classList.remove('is-drag'); go(0); }
    });
    // a drag is not a click on the card under the pointer
    track.addEventListener('click', function (e) { if (moved) { e.preventDefault(); e.stopPropagation(); moved = false; } }, true);
    track.addEventListener('dragstart', function (e) { e.preventDefault(); });
  });

  /* ---------- All work grid: thumbnails, sector filter, close-up ---------- */
  (function () {
    var grid = document.querySelector('.work-grid');
    if (!grid) return;
    var P = window.ACE360_PAINT;
    var thumbs = Array.prototype.slice.call(document.querySelectorAll('.work-grid canvas[data-paint], .work-hero-fan canvas[data-paint]'));
    function paint(c) { if (!P || c.getAttribute('data-done')) return; c.setAttribute('data-done', '1'); P.paint(c, c.getAttribute('data-paint'), c.getAttribute('data-title')); }
    function paintVisible() {
      if (!('IntersectionObserver' in window)) { thumbs.forEach(paint); return; }
      var io = new IntersectionObserver(function (entries) {
        entries.forEach(function (e) { if (e.isIntersecting) { paint(e.target); io.unobserve(e.target); } });
      }, { rootMargin: '600px 0px' });
      thumbs.forEach(function (c) { io.observe(c); });
    }
    // Wait for the web fonts so the painted text uses Inter.
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(paintVisible); else paintVisible();
    // Repaint thumbnails already drawn once the product photos have loaded.
    // Dutch businesses' sample sites switch language with the page
    document.addEventListener('ace360:lang', function () { thumbs.forEach(function (c) { if (c.getAttribute('data-done')) { c.removeAttribute('data-done'); paint(c); } }); });
    if (P && P.onPhotos) P.onPhotos(function () { thumbs.forEach(function (c) { if (c.getAttribute('data-done')) { c.removeAttribute('data-done'); paint(c); } }); });

    var cards = Array.prototype.slice.call(grid.querySelectorAll('.wcard'));
    var chips = Array.prototype.slice.call(document.querySelectorAll('[data-filter]'));
    function applyFilter(b, animate) {
      var f = b.getAttribute('data-filter'), shown = [];
      chips.forEach(function (x) { var on = x === b; x.classList.toggle('is-on', on); x.setAttribute('aria-pressed', on ? 'true' : 'false'); });
      cards.forEach(function (c) { var ok = f === 'all' || c.getAttribute('data-sector') === f; c.hidden = !ok; if (ok) shown.push(c); });
      if (animate && hasGsap && !reduced) gsap.fromTo(shown, { y: 18, opacity: 0 }, { y: 0, opacity: 1, duration: 0.5, ease: 'power3.out', stagger: 0.04, overwrite: true });
      if (hasGsap) ScrollTrigger.refresh();
    }
    chips.forEach(function (b) { b.addEventListener('click', function () { applyFilter(b, true); }); });
    // ?sector=store (from the "See all" slide) opens the page filtered
    var wanted = null;
    try { wanted = new URLSearchParams(window.location.search).get('sector'); } catch (e) {}
    chips.forEach(function (b) { if (wanted && b.getAttribute('data-filter') === wanted) applyFilter(b, false); });

    var dlg = document.querySelector('.work-dialog');
    if (!dlg || typeof dlg.showModal !== 'function') return;
    var shot = dlg.querySelector('.work-dialog-shot'), opener = null;
    grid.addEventListener('click', function (e) {
      var btn = e.target.closest('.wcard-open');
      if (!btn) return;
      var card = btn.closest('.wcard'), cv = card.querySelector('canvas[data-paint]'), img = card.querySelector('img');
      shot.innerHTML = '';
      if (cv && P) {
        var big = document.createElement('canvas'); big.width = 1024; big.height = 640;
        P.paint(big, cv.getAttribute('data-paint'), cv.getAttribute('data-title'));
        shot.appendChild(big);
      } else if (img) { shot.appendChild(img.cloneNode()); }
      dlg.querySelector('[data-d-type]').innerHTML = card.querySelector('.wcard-meta').innerHTML;
      dlg.querySelector('[data-d-title]').textContent = card.querySelector('.wcard-title').firstChild.textContent.trim();
      dlg.querySelector('[data-d-more]').innerHTML = card.querySelector('.wcard-more').innerHTML;
      opener = btn;
      if (lenis) lenis.stop();
      dlg.showModal();
      if (hasGsap && !reduced) gsap.fromTo(dlg.querySelector('.work-dialog-inner'), { y: 30, opacity: 0, scale: 0.98 }, { y: 0, opacity: 1, scale: 1, duration: 0.5, ease: 'power3.out' });
    });
    dlg.addEventListener('click', function (e) { if (e.target === dlg || e.target.closest('[data-close]')) dlg.close(); });
    dlg.addEventListener('close', function () { if (lenis) lenis.start(); if (opener) opener.focus(); });
  })();

  if (!hasGsap || reduced) return;

  /* ---------- Reveals ---------- */
  var hl = document.querySelectorAll('.hero-title .hl');
  var heroBits = document.querySelectorAll('.hero .kicker, .hero-title, .hero .lede, .hero .actions, .hero .checks li');
  var intro = gsap.timeline({ delay: 0.15 });
  if (heroBits.length) intro.from(heroBits, { y: 22, opacity: 0, duration: 0.9, ease: 'power3.out', stagger: 0.06 });
  if (hl.length) intro.fromTo(hl, { '--u': 0 }, { '--u': 1, duration: 0.9, ease: 'power3.inOut' }, 0.6);

  document.querySelectorAll('.ch:not(.hero):not(.tall) .copy').forEach(function (c) {
    var bits = c.querySelectorAll(':scope > .kicker, :scope > h2, :scope > .lede, :scope > .progress, :scope > .step-index');
    if (!bits.length) return;
    gsap.from(bits, { y: 26, opacity: 0, duration: 0.9, ease: 'power3.out', stagger: 0.07, scrollTrigger: { trigger: c, start: 'top 82%', once: true } });
  });
  document.querySelectorAll('.band .sec-head').forEach(function (h) {
    if (!h.children.length) return;
    gsap.from(h.children, { y: 24, opacity: 0, duration: 0.85, ease: 'power3.out', stagger: 0.07, scrollTrigger: { trigger: h, start: 'top 85%', once: true } });
  });
  ScrollTrigger.batch('.svc li, .step-index li, .pains li, .outcomes li, .faq details, .wcard, .contact-form, .direct, .quote-opts, .quote-result, .demo', {
    start: 'top 90%',
    once: true,
    onEnter: function (els) { gsap.from(els, { y: 30, opacity: 0, duration: 0.85, ease: 'power3.out', stagger: 0.08 }); }
  });

  if (document.fonts && document.fonts.ready) document.fonts.ready.then(function () { ScrollTrigger.refresh(); });
  window.addEventListener('load', function () { ScrollTrigger.refresh(); });
})();
